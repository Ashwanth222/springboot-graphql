package com.techprimers.graphql.springbootgrapqlexample;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootGrapqlExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootGrapqlExampleApplication.class, args);
	}
}
